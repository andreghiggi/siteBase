<div id="aguarde" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title" id="modal-title">Aguarde...</h1>
      </div>
      <div class="modal-body" id="modal-body" style="font-size: 18px;">
        <a href="" id="verBoleto" target="_blank" style="display: none"><button class="btn btn-success btn-block">Ver o meu boleto</button></a>
      </div>

    </div>

  </div>
</div>